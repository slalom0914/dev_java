create view EMP_DEPT_VIEW as
SELECT emp.empno, emp.ename, dept.dname, emp.deptno
FROM emp, dept
WHERE emp.deptno = dept.deptno
 AND emp.deptno IN (10,30)
/

