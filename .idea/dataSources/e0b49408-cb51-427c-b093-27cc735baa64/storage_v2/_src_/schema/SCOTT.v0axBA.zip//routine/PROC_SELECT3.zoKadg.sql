create procedure proc_select3(n_i in number)
is
  u_empno number(5):=0;
  u_ename varchar2(30):='';
begin
  -- select..into 는 단일행에 대해서만 사용가능함.
  -- 만일 다중행에 대해서 처리해야 한다면 커서를 사용할것.  
  select empno, ename into u_empno, u_ename
    from emp
   where empno > n_i; -- 7000이면 여러 로우가 반환됨
   if sql%rowcount = 1 then
     dbms_output.put_line('사번:'||u_empno||', 성명:'||u_ename);  
   elsif sql%rowcount = 0 then
     dbms_output.put_line('조회 결과가 없습니다.');
   elsif sql%rowcount > 1 then
     dbms_output.put_line('조회된 결과가 너무 많습니다.커서를 사용할것.');
   end if;
end;
/

