create procedure proc_emp_sal_update(p_empno in number)
is
  --변수 선언 및 초기화
  n_deptno number(5):=0;
  n_avg_sal number(7,2):=0.0;
  n_rate number(3,1):=0.0;
  n_sal number(7,2):=0.0;--파라미터로 받은 사번에 대응하는 급여액
begin
  -- 실행문(변수 재정의,조건문,반복문, 예외처리...)
  --1.파라미터로 받은 사번의 부서번호를 찾아서 n_deptno에 담기
  SELECT deptno,sal INTO n_deptno, n_sal
    FROM emp WHERE empno = p_empno;
  --2.위에서 받은 부서번호로 해당 부서의 급여 평균을 구해서 n_avg_sal담기
  SELECT AVG(sal) INTO n_avg_sal
    FROM emp WHERE deptno = n_deptno;
  --3.파라미터로 받은 사원의 급여액을 구해서 n_avg_sal과 비교한 후 할증을 결정하기
  IF n_sal > n_avg_sal THEN
    n_rate := 1.1;
  ELSE
    n_rate :=1.2;
  END IF;
  --4.n_rate를 활용하여 인상된 급여액을 테이블에 반영하기- update문
  UPDATE emp
     SET sal = sal * n_rate
  WHERE empno = p_empno;
  dbms_output.put_line(p_empno||'사원의 '||n_sal||'이 할증'||n_rate||'가 적용되어'||n_sal*n_rate||'가 되었습니다.');
  --5.commit
  commit;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      dbms_output.put_line(p_empno||'에 해당되는 사원이 없습니다.');
    WHEN others THEN
      dbms_output.put_line('에러 발생'||SQLERRM);
      rollback;
end;
/

