create procedure proc_exception2(n_i in number)
is
  err_num number(10):=0;
  err_msg varchar2(200):='';
  tmp number(5):=0;
begin
  -- 예외가 발생할 가능성이 있는 코드
  tmp := 120/0;
  exception 
    when others then
        err_num := SQLCODE;
        err_msg := SUBSTR(SQLERRM, 1,100);
        dbms_output.put_line('에러코드:'||err_num);
        dbms_output.put_line('에러내용:'||err_msg);
end;
/

