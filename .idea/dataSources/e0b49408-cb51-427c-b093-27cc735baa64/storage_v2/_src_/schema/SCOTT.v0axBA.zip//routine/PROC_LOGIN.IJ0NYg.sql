create procedure       proc_login(p_id in varchar2
                          , p_pw in varchar2
                          , result out number, msg out varchar2)
IS
BEGIN
    SELECT
        NVL((    
             SELECT 1 FROM dual --아이디가 존재해
              WHERE EXISTS (SELECT mem_name FROM member
                             WHERE mem_id=p_id)       
           ),-1) into result -- -1이면 아이디 없어.
    FROM dual; 
    IF result  = 1 THEN --1이면 비번도 검사해줄래?
       SELECT NVL((
                   SELECT 1 FROM member
                    WHERE mem_id =p_id
                      AND mem_pw =p_pw           
                  ),0) into result
         FROM dual;
       IF result = 0 THEN
        msg:='비밀번호가 틀렸습니다.';
       ELSE
        msg:='로그인 성공';
       END IF;
    ElSE 
        msg:='아이디가 존재하지 않습니다.';
    END IF;         
END;
/

