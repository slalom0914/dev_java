create view EMP_VIEW as
SELECT empno, ename
FROM emp
WHERE deptno = 10
/

