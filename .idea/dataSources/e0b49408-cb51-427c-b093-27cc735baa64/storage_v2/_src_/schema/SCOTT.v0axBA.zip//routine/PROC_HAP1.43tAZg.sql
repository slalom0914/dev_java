create procedure proc_hap1(temp in number)
is
-- 변수 선언 -- 한 번에 하나만 기억할 수 있다.
  n_i number(5) :=0;
  n_sum number(5) :=0; 
begin
  --n_i := -1;--0->-1
  loop
    n_i := n_i + 1;
    dbms_output.put_line('n_i:'||n_i);
    --> n_sum:=0+1, 1+2, 3+3, 6+4, 10+5, 15+6, 21+7, 28+8, 36+9, 45+10
    n_sum := n_sum + n_i; --누적되는 합을 계속 구한다.
    dbms_output.put_line('n_sum:'||n_sum);
    exit when n_i >=10;
  end loop;
  dbms_output.put_line('여기'||n_sum);
end;
/

