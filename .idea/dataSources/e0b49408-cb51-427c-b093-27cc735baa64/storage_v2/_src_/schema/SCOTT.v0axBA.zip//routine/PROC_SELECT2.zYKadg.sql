create procedure proc_select2(n_i in number)
is
  u_empno number(5):=0;
  u_ename varchar2(30):='';
begin
  select empno, ename into u_empno, u_ename
    from emp
   where empno = n_i;
   if sql%found then
     dbms_output.put_line('조회 결과가 있습니다.');
   end if;
   if sql%rowcount = 1 then
     dbms_output.put_line('사번:'||u_empno||', 성명:'||u_ename);  
   elsif sql%rowcount = 0 then
     dbms_output.put_line('조회 결과가 없습니다.');
   end if;
end;
/

