create procedure proc_test1(
    p_empno IN emp.empno%TYPE  
   ,msg OUT varchar2
)
is
 n_i number(5):=100;
 v_name varchar2(30):='';
begin
 v_name := '홍길동';
 msg:= '변수 n_i='||n_i||', 이름:'||v_name;
 dbms_output.put_line('변수 n_i='||n_i||', 이름:'||v_name);
end;
/

