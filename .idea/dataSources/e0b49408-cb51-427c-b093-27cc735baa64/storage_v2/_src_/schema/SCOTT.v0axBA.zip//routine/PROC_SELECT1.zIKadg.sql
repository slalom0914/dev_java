create procedure proc_select1(n_i in number)
is
  u_empno number(5):=0;
  u_ename varchar2(30):='';
begin
  select empno, ename into u_empno, u_ename
    from emp
   where empno = n_i;
   dbms_output.put_line('사번:'||u_empno||', 성명:'||u_ename);  
end;
/

